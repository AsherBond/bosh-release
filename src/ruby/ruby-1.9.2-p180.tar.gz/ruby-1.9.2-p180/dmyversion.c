#define NO_INITIAL_LOAD_PATH 1
#include "version.c"
