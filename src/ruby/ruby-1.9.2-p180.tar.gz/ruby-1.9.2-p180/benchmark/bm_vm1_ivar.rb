@a = 1

i = 0
while i<30000000 # while loop 1
  i+= 1
  j = @a
  k = @a
end
