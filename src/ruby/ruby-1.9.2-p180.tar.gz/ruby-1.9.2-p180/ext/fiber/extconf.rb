require 'mkmf'
create_makefile('fiber')

