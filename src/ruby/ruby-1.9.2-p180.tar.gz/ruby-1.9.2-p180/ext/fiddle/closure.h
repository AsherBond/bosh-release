#ifndef FIDDLE_CLOSURE_H
#define FIDDLE_CLOSURE_H

#include <fiddle.h>

void Init_fiddle_closure();

#endif
