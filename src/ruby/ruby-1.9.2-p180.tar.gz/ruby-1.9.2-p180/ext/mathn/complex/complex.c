extern void nucomp_canonicalization(int);

void
Init_complex(void)
{
    nucomp_canonicalization(1);
}
